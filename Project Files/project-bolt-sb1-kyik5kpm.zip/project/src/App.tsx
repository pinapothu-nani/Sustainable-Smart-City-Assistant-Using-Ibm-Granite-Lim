import React, { useState } from 'react';
import { Building2, FileText, MessageSquare, TrendingUp, AlertTriangle, Leaf, Bot } from 'lucide-react';
import Header from './components/Header';
import Navigation from './components/Navigation';
import PolicySummarization from './components/PolicySummarization';
import CitizenFeedback from './components/CitizenFeedback';
import KPIForecasting from './components/KPIForecasting';
import AnomalyDetection from './components/AnomalyDetection';
import EcoTips from './components/EcoTips';
import ChatAssistant from './components/ChatAssistant';
import Dashboard from './components/Dashboard';

type TabType = 'dashboard' | 'policy' | 'feedback' | 'kpi' | 'anomaly' | 'eco' | 'chat';

const tabs = [
  { id: 'dashboard' as TabType, label: 'Dashboard', icon: Building2 },
  { id: 'policy' as TabType, label: 'Policy Summarization', icon: FileText },
  { id: 'feedback' as TabType, label: 'Citizen Feedback', icon: MessageSquare },
  { id: 'kpi' as TabType, label: 'KPI Forecasting', icon: TrendingUp },
  { id: 'anomaly' as TabType, label: 'Anomaly Detection', icon: AlertTriangle },
  { id: 'eco' as TabType, label: 'Eco Tips', icon: Leaf },
  { id: 'chat' as TabType, label: 'Chat Assistant', icon: Bot },
];

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');

  const renderActiveTab = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'policy':
        return <PolicySummarization />;
      case 'feedback':
        return <CitizenFeedback />;
      case 'kpi':
        return <KPIForecasting />;
      case 'anomaly':
        return <AnomalyDetection />;
      case 'eco':
        return <EcoTips />;
      case 'chat':
        return <ChatAssistant />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-green-50">
      <Header />
      <div className="flex">
        <Navigation 
          tabs={tabs} 
          activeTab={activeTab} 
          onTabChange={setActiveTab} 
        />
        <main className="flex-1 p-6 ml-64">
          <div className="max-w-7xl mx-auto">
            {renderActiveTab()}
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;