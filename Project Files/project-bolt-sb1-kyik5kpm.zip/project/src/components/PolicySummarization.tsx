import React, { useState } from 'react';
import { Upload, FileText, Loader2, CheckCircle } from 'lucide-react';

const PolicySummarization: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [extractedText, setExtractedText] = useState<string>('');
  const [summary, setSummary] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  const handleFileUpload = (uploadedFile: File) => {
    setFile(uploadedFile);
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      setExtractedText(text);
    };
    reader.readAsText(uploadedFile);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = e.dataTransfer.files;
    if (files && files[0] && files[0].type === "text/plain") {
      handleFileUpload(files[0]);
    }
  };

  const handleSummarize = async () => {
    if (!extractedText) return;
    
    setLoading(true);
    try {
      const response = await fetch("http://localhost:8000/summarize", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ content: extractedText }),
      });
      
      if (response.ok) {
        const data = await response.json();
        setSummary(data.summary);
      } else {
        setSummary("Error: Unable to generate summary. Please check your backend connection.");
      }
    } catch (error) {
      setSummary("Error: Backend connection failed. Please ensure your FastAPI server is running.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-slate-900 mb-2">Policy Document Summarization</h2>
        <p className="text-slate-600">Upload policy documents to get AI-powered summaries using IBM Granite LLM</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Upload Section */}
        <div className="space-y-6">
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
            <h3 className="text-xl font-semibold text-slate-900 mb-4 flex items-center">
              <Upload className="h-5 w-5 mr-2 text-blue-500" />
              Upload Document
            </h3>
            
            <div
              className={`border-2 border-dashed rounded-xl p-8 text-center transition-all ${
                dragActive
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-slate-300 hover:border-blue-400 hover:bg-slate-50'
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <FileText className="h-12 w-12 text-slate-400 mx-auto mb-4" />
              <p className="text-slate-600 mb-4">
                Drag and drop your policy document here, or click to browse
              </p>
              <input
                type="file"
                accept=".txt"
                onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0])}
                className="hidden"
                id="file-upload"
              />
              <label
                htmlFor="file-upload"
                className="inline-flex items-center px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 cursor-pointer transition-colors"
              >
                <Upload className="h-4 w-4 mr-2" />
                Choose File
              </label>
              {file && (
                <div className="mt-4 p-3 bg-green-50 rounded-lg flex items-center justify-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-green-700 font-medium">{file.name}</span>
                </div>
              )}
            </div>
          </div>

          {extractedText && (
            <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
              <h3 className="text-lg font-semibold text-slate-900 mb-4">Extracted Text</h3>
              <div className="bg-slate-50 rounded-lg p-4 max-h-64 overflow-y-auto">
                <pre className="text-sm text-slate-700 whitespace-pre-wrap">{extractedText}</pre>
              </div>
              <button
                onClick={handleSummarize}
                disabled={loading}
                className="mt-4 w-full flex items-center justify-center px-6 py-3 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-lg hover:from-blue-600 hover:to-green-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Generating Summary...
                  </>
                ) : (
                  <>
                    <FileText className="h-4 w-4 mr-2" />
                    Generate Summary
                  </>
                )}
              </button>
            </div>
          )}
        </div>

        {/* Summary Section */}
        <div className="space-y-6">
          {summary && (
            <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
              <h3 className="text-xl font-semibold text-slate-900 mb-4 flex items-center">
                <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
                AI-Generated Summary
              </h3>
              <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-6">
                <p className="text-slate-800 leading-relaxed">{summary}</p>
              </div>
            </div>
          )}
          
          {!summary && !loading && (
            <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200 text-center">
              <FileText className="h-16 w-16 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-900 mb-2">Ready to Summarize</h3>
              <p className="text-slate-600">Upload a policy document to get started with AI-powered summarization</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PolicySummarization;