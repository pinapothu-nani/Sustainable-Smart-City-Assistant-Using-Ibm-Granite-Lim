import React from 'react';
import { Building2, Zap } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-r from-blue-500 to-green-500 rounded-xl">
              <Building2 className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">
                Sustainable Smart City Assistant
              </h1>
              <p className="text-sm text-slate-600">Powered by IBM Granite LLM</p>
            </div>
          </div>
          <div className="flex items-center space-x-2 px-3 py-1.5 bg-green-100 text-green-700 rounded-full text-sm font-medium">
            <Zap className="h-4 w-4" />
            <span>AI Powered</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;