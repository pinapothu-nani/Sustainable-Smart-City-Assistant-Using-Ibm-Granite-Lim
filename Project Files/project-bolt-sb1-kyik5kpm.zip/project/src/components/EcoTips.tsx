import React, { useState } from 'react';
import { Leaf, Search, Lightbulb, Recycle, Droplets, Zap } from 'lucide-react';

const EcoTips: React.FC = () => {
  const [keyword, setKeyword] = useState('');
  const [tips, setTips] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('');

  const categories = [
    { id: 'energy', label: 'Energy', icon: Zap, color: 'yellow' },
    { id: 'water', label: 'Water', icon: Droplets, color: 'blue' },
    { id: 'waste', label: 'Waste', icon: Recycle, color: 'green' },
    { id: 'transport', label: 'Transport', icon: Leaf, color: 'emerald' },
  ];

  const featuredTips = [
    {
      category: 'Energy',
      icon: Zap,
      title: 'Smart Home Energy',
      tip: 'Install programmable thermostats to reduce energy consumption by up to 23% annually.',
      color: 'yellow',
    },
    {
      category: 'Water',
      icon: Droplets,
      title: 'Water Conservation',
      tip: 'Fix leaky faucets immediately - a single drop per second wastes over 3,000 gallons per year.',
      color: 'blue',
    },
    {
      category: 'Waste',
      icon: Recycle,
      title: 'Circular Economy',
      tip: 'Compost organic waste to reduce household waste by 30% and create nutrient-rich soil.',
      color: 'green',
    },
    {
      category: 'Transport',
      icon: Leaf,
      title: 'Green Mobility',
      tip: 'Use public transport or bike for trips under 3 miles to reduce carbon footprint by 2.6 tons annually.',
      color: 'emerald',
    },
  ];

  const sampleTipsByKeyword: { [key: string]: string[] } = {
    plastic: [
      'Use reusable water bottles and coffee cups to reduce single-use plastic consumption',
      'Choose products with minimal plastic packaging or biodegradable alternatives',
      'Participate in local plastic recycling programs and beach cleanup initiatives',
      'Switch to bamboo or metal straws instead of plastic ones',
    ],
    solar: [
      'Install solar panels to generate clean energy and reduce electricity bills by 70-90%',
      'Use solar-powered outdoor lighting for gardens and pathways',
      'Consider community solar programs if rooftop installation is not feasible',
      'Invest in solar water heaters to reduce energy consumption for hot water',
    ],
    recycling: [
      'Sort waste properly: paper, plastic, glass, and metals in separate containers',
      'Clean containers before recycling to ensure they can be processed effectively',
      'Donate or upcycle items instead of throwing them away',
      'Learn about e-waste recycling for old electronics and batteries',
    ],
    energy: [
      'Switch to LED bulbs which use 75% less energy than incandescent bulbs',
      'Unplug electronics when not in use to prevent phantom energy drain',
      'Use energy-efficient appliances with ENERGY STAR certification',
      'Improve home insulation to reduce heating and cooling costs',
    ],
  };

  const handleGenerateTips = async () => {
    if (!keyword.trim()) return;

    setLoading(true);
    try {
      const response = await fetch("http://localhost:8000/eco_tips", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ keyword }),
      });

      if (response.ok) {
        const data = await response.json();
        setTips(data.tips ? data.tips.split('\n').filter((tip: string) => tip.trim()) : []);
      } else {
        // Fallback to sample tips
        const keywordLower = keyword.toLowerCase();
        const foundTips = sampleTipsByKeyword[keywordLower] || [
          `Here are some eco-friendly tips related to "${keyword}":`,
          'Reduce consumption and choose sustainable alternatives',
          'Support local and environmentally conscious businesses',
          'Share knowledge with your community to multiply the impact',
        ];
        setTips(foundTips);
      }
    } catch (error) {
      const keywordLower = keyword.toLowerCase();
      const foundTips = sampleTipsByKeyword[keywordLower] || [
        `Here are some eco-friendly tips related to "${keyword}":`,
        'Reduce consumption and choose sustainable alternatives',
        'Support local and environmentally conscious businesses',
        'Share knowledge with your community to multiply the impact',
      ];
      setTips(foundTips);
    } finally {
      setLoading(false);
    }
  };

  const getCategoryColor = (color: string) => {
    const colors = {
      yellow: 'from-yellow-500 to-orange-500',
      blue: 'from-blue-500 to-cyan-500',
      green: 'from-green-500 to-emerald-500',
      emerald: 'from-emerald-500 to-teal-500',
    };
    return colors[color as keyof typeof colors];
  };

  const getCategoryBg = (color: string) => {
    const colors = {
      yellow: 'bg-yellow-50 border-yellow-200',
      blue: 'bg-blue-50 border-blue-200',
      green: 'bg-green-50 border-green-200',
      emerald: 'bg-emerald-50 border-emerald-200',
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-slate-900 mb-2">Eco Tips Generator</h2>
        <p className="text-slate-600">Get personalized sustainability advice powered by AI to make your city greener</p>
      </div>

      {/* Featured Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {categories.map((category) => {
          const Icon = category.icon;
          return (
            <button
              key={category.id}
              onClick={() => {
                setKeyword(category.id);
                setSelectedCategory(category.id);
              }}
              className={`p-6 rounded-2xl border-2 transition-all text-left ${
                selectedCategory === category.id
                  ? getCategoryBg(category.color)
                  : 'bg-white/70 border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className={`p-3 bg-gradient-to-r ${getCategoryColor(category.color)} rounded-xl w-fit mb-4`}>
                <Icon className="h-6 w-6 text-white" />
              </div>
              <h3 className="font-semibold text-slate-900">{category.label}</h3>
              <p className="text-sm text-slate-600 mt-1">Get tips for {category.label.toLowerCase()}</p>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Tip Generator */}
        <div className="space-y-6">
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
            <h3 className="text-xl font-semibold text-slate-900 mb-4 flex items-center">
              <Search className="h-5 w-5 mr-2 text-green-500" />
              Generate Custom Tips
            </h3>
            
            <div className="space-y-4">
              <div>
                <label htmlFor="keyword" className="block text-sm font-medium text-slate-700 mb-2">
                  Enter keyword or topic
                </label>
                <input
                  id="keyword"
                  type="text"
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                  placeholder="e.g., plastic, solar, recycling, energy..."
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  onKeyPress={(e) => e.key === 'Enter' && handleGenerateTips()}
                />
              </div>
              
              <button
                onClick={handleGenerateTips}
                disabled={loading || !keyword.trim()}
                className="w-full flex items-center justify-center px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-lg hover:from-green-600 hover:to-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Generating Tips...
                  </>
                ) : (
                  <>
                    <Lightbulb className="h-4 w-4 mr-2" />
                    Generate Eco Tips
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Generated Tips */}
          {tips.length > 0 && (
            <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
              <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center">
                <Lightbulb className="h-5 w-5 mr-2 text-yellow-500" />
                Your Personalized Tips
              </h3>
              <div className="space-y-3">
                {tips.map((tip, index) => (
                  <div key={index} className="flex items-start space-x-3 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs font-bold text-green-600">{index + 1}</span>
                    </div>
                    <p className="text-slate-800 leading-relaxed">{tip}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Featured Tips */}
        <div className="space-y-6">
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
            <h3 className="text-xl font-semibold text-slate-900 mb-6">Featured Sustainability Tips</h3>
            <div className="space-y-4">
              {featuredTips.map((tip, index) => {
                const Icon = tip.icon;
                return (
                  <div key={index} className={`p-4 rounded-lg border-2 ${getCategoryBg(tip.color)}`}>
                    <div className="flex items-center mb-3">
                      <div className={`p-2 bg-gradient-to-r ${getCategoryColor(tip.color)} rounded-lg mr-3`}>
                        <Icon className="h-4 w-4 text-white" />
                      </div>
                      <div>
                        <span className="text-xs font-medium text-slate-500 uppercase tracking-wide">{tip.category}</span>
                        <h4 className="font-semibold text-slate-900">{tip.title}</h4>
                      </div>
                    </div>
                    <p className="text-sm text-slate-700 leading-relaxed">{tip.tip}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Quick Eco Topics</h3>
            <div className="flex flex-wrap gap-2">
              {Object.keys(sampleTipsByKeyword).map((topic) => (
                <button
                  key={topic}
                  onClick={() => {
                    setKeyword(topic);
                    setSelectedCategory('');
                  }}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-green-100 text-slate-700 hover:text-green-800 rounded-full text-sm font-medium transition-colors capitalize"
                >
                  {topic}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Impact Stats */}
      <div className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl p-8 text-white">
        <h3 className="text-2xl font-bold mb-6 text-center">Your Eco Impact Potential</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="text-3xl font-bold mb-2">2.6 tons</div>
            <div className="text-green-100">CO₂ saved annually</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold mb-2">$1,200</div>
            <div className="text-green-100">Potential savings per year</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold mb-2">85%</div>
            <div className="text-green-100">Waste reduction possible</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EcoTips;