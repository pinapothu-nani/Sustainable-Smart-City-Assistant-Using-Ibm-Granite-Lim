import React, { useState } from 'react';
import { MessageSquare, Tag, Send, CheckCircle, AlertCircle } from 'lucide-react';

const CitizenFeedback: React.FC = () => {
  const [feedback, setFeedback] = useState('');
  const [tags, setTags] = useState('');
  const [category, setCategory] = useState('general');
  const [priority, setPriority] = useState('medium');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const categories = [
    { value: 'water', label: 'Water & Utilities', color: 'blue' },
    { value: 'transport', label: 'Transportation', color: 'green' },
    { value: 'environment', label: 'Environment', color: 'emerald' },
    { value: 'safety', label: 'Public Safety', color: 'red' },
    { value: 'infrastructure', label: 'Infrastructure', color: 'purple' },
    { value: 'general', label: 'General', color: 'gray' },
  ];

  const priorities = [
    { value: 'low', label: 'Low Priority', color: 'green' },
    { value: 'medium', label: 'Medium Priority', color: 'yellow' },
    { value: 'high', label: 'High Priority', color: 'red' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedback.trim()) return;

    setLoading(true);
    try {
      const response = await fetch("http://localhost:8000/feedback", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          text: feedback,
          tags: tags.split(',').map(tag => tag.trim()).filter(tag => tag),
          category,
          priority,
        }),
      });

      if (response.ok) {
        setSubmitted(true);
        setFeedback('');
        setTags('');
        setCategory('general');
        setPriority('medium');
        setTimeout(() => setSubmitted(false), 3000);
      }
    } catch (error) {
      console.error('Error submitting feedback:', error);
    } finally {
      setLoading(false);
    }
  };

  const getCategoryColor = (color: string) => {
    const colors = {
      blue: 'bg-blue-100 text-blue-800 border-blue-200',
      green: 'bg-green-100 text-green-800 border-green-200',
      emerald: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      red: 'bg-red-100 text-red-800 border-red-200',
      purple: 'bg-purple-100 text-purple-800 border-purple-200',
      gray: 'bg-gray-100 text-gray-800 border-gray-200',
      yellow: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-slate-900 mb-2">Citizen Feedback Portal</h2>
        <p className="text-slate-600">Report issues, share suggestions, and help improve your city</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Feedback Form */}
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
          <h3 className="text-xl font-semibold text-slate-900 mb-6 flex items-center">
            <MessageSquare className="h-5 w-5 mr-2 text-blue-500" />
            Submit Your Feedback
          </h3>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Category
              </label>
              <div className="grid grid-cols-2 gap-2">
                {categories.map((cat) => (
                  <button
                    key={cat.value}
                    type="button"
                    onClick={() => setCategory(cat.value)}
                    className={`p-3 rounded-lg border text-sm font-medium transition-all ${
                      category === cat.value
                        ? getCategoryColor(cat.color)
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Priority Level
              </label>
              <div className="flex space-x-2">
                {priorities.map((pri) => (
                  <button
                    key={pri.value}
                    type="button"
                    onClick={() => setPriority(pri.value)}
                    className={`flex-1 p-2 rounded-lg border text-sm font-medium transition-all ${
                      priority === pri.value
                        ? getCategoryColor(pri.color)
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {pri.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label htmlFor="feedback" className="block text-sm font-medium text-slate-700 mb-2">
                Describe the Issue or Suggestion
              </label>
              <textarea
                id="feedback"
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                placeholder="Please provide detailed information about your feedback..."
                rows={6}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                required
              />
            </div>

            <div>
              <label htmlFor="tags" className="block text-sm font-medium text-slate-700 mb-2 flex items-center">
                <Tag className="h-4 w-4 mr-1" />
                Tags (comma-separated)
              </label>
              <input
                id="tags"
                type="text"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                placeholder="e.g., urgent, pothole, main-street"
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <button
              type="submit"
              disabled={loading || !feedback.trim()}
              className="w-full flex items-center justify-center px-6 py-3 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-lg hover:from-blue-600 hover:to-green-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Submitting...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Submit Feedback
                </>
              )}
            </button>

            {submitted && (
              <div className="flex items-center justify-center p-4 bg-green-50 border border-green-200 rounded-lg">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                <span className="text-green-700 font-medium">Feedback submitted successfully!</span>
              </div>
            )}
          </form>
        </div>

        {/* Information Panel */}
        <div className="space-y-6">
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
            <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center">
              <AlertCircle className="h-5 w-5 mr-2 text-yellow-500" />
              Guidelines for Effective Feedback
            </h3>
            <ul className="space-y-3 text-sm text-slate-600">
              <li className="flex items-start">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <span>Be specific about the location and nature of the issue</span>
              </li>
              <li className="flex items-start">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <span>Include relevant details like time, weather conditions, or affected services</span>
              </li>
              <li className="flex items-start">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <span>Use appropriate tags to help categorize your feedback</span>
              </li>
              <li className="flex items-start">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <span>Select the correct priority level based on urgency</span>
              </li>
            </ul>
          </div>

          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Recent Submissions</h3>
            <div className="space-y-3">
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs px-2 py-1 bg-blue-100 text-blue-800 rounded-full">Water</span>
                  <span className="text-xs text-slate-500">2 hours ago</span>
                </div>
                <p className="text-sm text-slate-700">Water leak reported on Oak Avenue</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs px-2 py-1 bg-green-100 text-green-800 rounded-full">Transport</span>
                  <span className="text-xs text-slate-500">5 hours ago</span>
                </div>
                <p className="text-sm text-slate-700">Request for additional bus stops</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs px-2 py-1 bg-red-100 text-red-800 rounded-full">Safety</span>
                  <span className="text-xs text-slate-500">1 day ago</span>
                </div>
                <p className="text-sm text-slate-700">Broken streetlight on Pine Street</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CitizenFeedback;