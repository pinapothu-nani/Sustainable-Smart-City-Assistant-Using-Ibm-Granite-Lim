import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, User, Loader2, Lightbulb, HelpCircle } from 'lucide-react';

interface Message {
  id: number;
  text: string;
  isUser: boolean;
  timestamp: Date;
}

const ChatAssistant: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hello! I'm your Sustainable Smart City Assistant powered by IBM Granite LLM. I can help you with city planning, sustainability questions, policy insights, and much more. How can I assist you today?",
      isUser: false,
      timestamp: new Date(),
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const sampleQuestions = [
    "How can my city reduce carbon emissions?",
    "What are the best practices for smart waste management?",
    "How do I implement green infrastructure in urban planning?",
    "What are effective citizen engagement strategies?",
  ];

  const sampleResponses: { [key: string]: string } = {
    "carbon emissions": "To reduce carbon emissions in your city, consider implementing: 1) Green building standards and energy-efficient retrofits, 2) Expanding public transportation and cycling infrastructure, 3) Transitioning to renewable energy sources, 4) Creating urban forests and green spaces, 5) Implementing congestion pricing and low-emission zones, 6) Supporting electric vehicle adoption with charging infrastructure, 7) Promoting circular economy practices and waste reduction programs.",
    "waste management": "Smart waste management strategies include: 1) IoT-enabled smart bins with fill-level sensors, 2) Route optimization for collection trucks using AI, 3) Implementing comprehensive recycling and composting programs, 4) Pay-as-you-throw pricing models, 5) Waste-to-energy facilities for non-recyclable materials, 6) Community education and engagement programs, 7) Digital tracking systems for waste streams and performance metrics.",
    "green infrastructure": "Green infrastructure implementation involves: 1) Green roofs and living walls to manage stormwater and improve air quality, 2) Permeable pavements and bioswales for natural water filtration, 3) Urban tree canopy expansion for cooling and carbon sequestration, 4) Green corridors connecting natural areas, 5) Rain gardens and constructed wetlands, 6) Cool roof programs to reduce urban heat island effect, 7) Integration with traditional gray infrastructure for maximum efficiency.",
    "citizen engagement": "Effective citizen engagement strategies include: 1) Digital platforms for participatory budgeting and decision-making, 2) Regular town halls and community forums, 3) Mobile apps for reporting issues and accessing city services, 4) Co-creation workshops for policy development, 5) Neighborhood ambassadors and community liaisons, 6) Transparent communication about city projects and spending, 7) Gamification of civic participation and sustainability actions."
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const newMessage: Message = {
      id: messages.length + 1,
      text: inputMessage,
      isUser: true,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, newMessage]);
    setInputMessage('');
    setLoading(true);

    try {
      const response = await fetch("http://localhost:8000/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ query: inputMessage }),
      });

      let responseText = "I apologize, but I'm having trouble connecting to the backend service. However, I can still provide some general guidance on your question.";

      if (response.ok) {
        const data = await response.json();
        responseText = data.response;
      } else {
        // Fallback to sample responses
        const query = inputMessage.toLowerCase();
        for (const [key, value] of Object.entries(sampleResponses)) {
          if (query.includes(key)) {
            responseText = value;
            break;
          }
        }
      }

      const assistantMessage: Message = {
        id: messages.length + 2,
        text: responseText,
        isUser: false,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: Message = {
        id: messages.length + 2,
        text: "I'm currently experiencing connectivity issues. Please ensure your FastAPI backend is running on localhost:8000. In the meantime, I can still help with general sustainability and city planning questions!",
        isUser: false,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const handleQuestionClick = (question: string) => {
    setInputMessage(question);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-slate-900 mb-2">AI Chat Assistant</h2>
        <p className="text-slate-600">Ask questions about sustainable city planning, policies, and best practices</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Chat Interface */}
        <div className="lg:col-span-3">
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl border border-slate-200 h-[600px] flex flex-col">
            {/* Chat Header */}
            <div className="p-6 border-b border-slate-200">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-gradient-to-r from-blue-500 to-green-500 rounded-xl">
                  <Bot className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900">Smart City Assistant</h3>
                  <p className="text-sm text-slate-600">Powered by IBM Granite LLM</p>
                </div>
                <div className="ml-auto">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}>
                  <div className={`flex items-start space-x-3 max-w-[80%] ${message.isUser ? 'flex-row-reverse space-x-reverse' : ''}`}>
                    <div className={`p-2 rounded-xl ${message.isUser ? 'bg-blue-500' : 'bg-slate-100'}`}>
                      {message.isUser ? (
                        <User className="h-4 w-4 text-white" />
                      ) : (
                        <Bot className="h-4 w-4 text-slate-600" />
                      )}
                    </div>
                    <div className={`p-4 rounded-2xl ${
                      message.isUser 
                        ? 'bg-blue-500 text-white' 
                        : 'bg-white border border-slate-200'
                    }`}>
                      <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.text}</p>
                      <p className={`text-xs mt-2 ${message.isUser ? 'text-blue-100' : 'text-slate-500'}`}>
                        {formatTime(message.timestamp)}
                      </p>
                    </div>
                  </div>
                </div>
              ))}

              {loading && (
                <div className="flex justify-start">
                  <div className="flex items-start space-x-3 max-w-[80%]">
                    <div className="p-2 rounded-xl bg-slate-100">
                      <Bot className="h-4 w-4 text-slate-600" />
                    </div>
                    <div className="p-4 rounded-2xl bg-white border border-slate-200">
                      <div className="flex items-center space-x-2">
                        <Loader2 className="h-4 w-4 animate-spin text-blue-500" />
                        <span className="text-sm text-slate-600">Thinking...</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="p-6 border-t border-slate-200">
              <div className="flex space-x-3">
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Ask about sustainability, city planning, policies..."
                  className="flex-1 px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  onKeyPress={(e) => e.key === 'Enter' && !loading && handleSendMessage()}
                  disabled={loading}
                />
                <button
                  onClick={handleSendMessage}
                  disabled={loading || !inputMessage.trim()}
                  className="px-6 py-3 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-lg hover:from-blue-600 hover:to-green-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                  <Send className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Sample Questions */}
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
            <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center">
              <HelpCircle className="h-5 w-5 mr-2 text-blue-500" />
              Sample Questions
            </h3>
            <div className="space-y-2">
              {sampleQuestions.map((question, index) => (
                <button
                  key={index}
                  onClick={() => handleQuestionClick(question)}
                  className="w-full text-left p-3 text-sm text-slate-600 hover:text-slate-900 hover:bg-slate-50 rounded-lg transition-colors"
                >
                  {question}
                </button>
              ))}
            </div>
          </div>

          {/* Tips */}
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
            <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center">
              <Lightbulb className="h-5 w-5 mr-2 text-yellow-500" />
              Chat Tips
            </h3>
            <ul className="space-y-3 text-sm text-slate-600">
              <li className="flex items-start">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <span>Ask specific questions about city sustainability initiatives</span>
              </li>
              <li className="flex items-start">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <span>Request policy recommendations for urban challenges</span>
              </li>
              <li className="flex items-start">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <span>Get insights on best practices from other cities</span>
              </li>
              <li className="flex items-start">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <span>Ask for implementation strategies and timelines</span>
              </li>
            </ul>
          </div>

          {/* AI Status */}
          <div className="bg-gradient-to-r from-blue-500 to-green-500 rounded-2xl p-6 text-white">
            <h3 className="font-semibold mb-2">AI Assistant Status</h3>
            <div className="flex items-center justify-between text-sm">
              <span>Model: IBM Granite LLM</span>
              <div className="flex items-center">
                <div className="w-2 h-2 bg-green-300 rounded-full mr-2"></div>
                <span>Online</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatAssistant;