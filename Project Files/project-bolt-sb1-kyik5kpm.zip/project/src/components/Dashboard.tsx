import React from 'react';
import { FileText, MessageSquare, TrendingUp, AlertTriangle, Leaf, Bot, Users, Activity } from 'lucide-react';

const Dashboard: React.FC = () => {
  const stats = [
    { label: 'Documents Processed', value: '1,247', icon: FileText, color: 'blue' },
    { label: 'Citizen Feedback', value: '348', icon: MessageSquare, color: 'green' },
    { label: 'KPI Forecasts', value: '89', icon: TrendingUp, color: 'purple' },
    { label: 'Anomalies Detected', value: '12', icon: AlertTriangle, color: 'red' },
  ];

  const recentActivity = [
    { type: 'policy', message: 'New policy document summarized: "Urban Green Spaces Initiative"', time: '2 hours ago' },
    { type: 'feedback', message: 'Citizen reported water leak on Main Street', time: '4 hours ago' },
    { type: 'forecast', message: 'Energy consumption forecast completed for Q2 2025', time: '6 hours ago' },
    { type: 'anomaly', message: 'Unusual traffic pattern detected in Zone 5', time: '8 hours ago' },
  ];

  const getStatColor = (color: string) => {
    const colors = {
      blue: 'from-blue-500 to-blue-600',
      green: 'from-green-500 to-green-600',
      purple: 'from-purple-500 to-purple-600',
      red: 'from-red-500 to-red-600',
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-slate-900 mb-2">City Dashboard</h2>
        <p className="text-slate-600">Monitor your smart city's performance and insights at a glance</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-600 text-sm font-medium">{stat.label}</p>
                  <p className="text-3xl font-bold text-slate-900 mt-1">{stat.value}</p>
                </div>
                <div className={`p-3 bg-gradient-to-r ${getStatColor(stat.color)} rounded-xl`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Feature Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
          <h3 className="text-xl font-semibold text-slate-900 mb-4 flex items-center">
            <Activity className="h-5 w-5 mr-2 text-blue-500" />
            Recent Activity
          </h3>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div key={index} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-slate-50 transition-colors">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                <div className="flex-1">
                  <p className="text-slate-900 text-sm font-medium">{activity.message}</p>
                  <p className="text-slate-500 text-xs mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
          <h3 className="text-xl font-semibold text-slate-900 mb-4 flex items-center">
            <Users className="h-5 w-5 mr-2 text-green-500" />
            Quick Actions
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <button className="p-4 text-left rounded-xl bg-gradient-to-r from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-200 transition-all group">
              <FileText className="h-6 w-6 text-blue-600 mb-2" />
              <p className="font-medium text-slate-900">Summarize Policy</p>
              <p className="text-xs text-slate-600">Upload document</p>
            </button>
            <button className="p-4 text-left rounded-xl bg-gradient-to-r from-green-50 to-green-100 hover:from-green-100 hover:to-green-200 transition-all group">
              <MessageSquare className="h-6 w-6 text-green-600 mb-2" />
              <p className="font-medium text-slate-900">Citizen Feedback</p>
              <p className="text-xs text-slate-600">Submit report</p>
            </button>
            <button className="p-4 text-left rounded-xl bg-gradient-to-r from-purple-50 to-purple-100 hover:from-purple-100 hover:to-purple-200 transition-all group">
              <TrendingUp className="h-6 w-6 text-purple-600 mb-2" />
              <p className="font-medium text-slate-900">KPI Forecast</p>
              <p className="text-xs text-slate-600">Predict trends</p>
            </button>
            <button className="p-4 text-left rounded-xl bg-gradient-to-r from-red-50 to-red-100 hover:from-red-100 hover:to-red-200 transition-all group">
              <Bot className="h-6 w-6 text-red-600 mb-2" />
              <p className="font-medium text-slate-900">AI Assistant</p>
              <p className="text-xs text-slate-600">Ask questions</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;