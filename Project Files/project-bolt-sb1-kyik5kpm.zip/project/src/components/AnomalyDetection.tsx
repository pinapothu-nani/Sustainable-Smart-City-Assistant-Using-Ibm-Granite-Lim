import React, { useState } from 'react';
import { Upload, AlertTriangle, Shield, TrendingDown, Eye } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ScatterChart, Scatter } from 'recharts';

const AnomalyDetection: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [data, setData] = useState<any[]>([]);
  const [anomalies, setAnomalies] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // Sample data with anomalies
  const sampleData = [
    { time: '00:00', value: 45, isAnomaly: false },
    { time: '02:00', value: 42, isAnomaly: false },
    { time: '04:00', value: 38, isAnomaly: false },
    { time: '06:00', value: 65, isAnomaly: false },
    { time: '08:00', value: 89, isAnomaly: false },
    { time: '10:00', value: 145, isAnomaly: true }, // Anomaly
    { time: '12:00', value: 78, isAnomaly: false },
    { time: '14:00', value: 82, isAnomaly: false },
    { time: '16:00', value: 15, isAnomaly: true }, // Anomaly
    { time: '18:00', value: 95, isAnomaly: false },
    { time: '20:00', value: 87, isAnomaly: false },
    { time: '22:00', value: 56, isAnomaly: false },
  ];

  const detectedAnomalies = [
    {
      id: 1,
      timestamp: '2024-01-15 10:00:00',
      metric: 'Energy Consumption',
      value: 145,
      expected: 75,
      severity: 'high',
      zone: 'Sector 12',
      deviation: 93.3,
    },
    {
      id: 2,
      timestamp: '2024-01-15 16:00:00',
      metric: 'Water Pressure',
      value: 15,
      expected: 45,
      severity: 'medium',
      zone: 'Zone A',
      deviation: -66.7,
    },
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0];
    if (uploadedFile) {
      setFile(uploadedFile);
      setData(sampleData);
    }
  };

  const handleDetectAnomalies = async () => {
    if (!data.length) return;

    setLoading(true);
    try {
      const response = await fetch("http://localhost:8000/anomaly_detect", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ data }),
      });

      if (response.ok) {
        const result = await response.json();
        setAnomalies(result.anomalies || detectedAnomalies);
      } else {
        setAnomalies(detectedAnomalies);
      }
    } catch (error) {
      setAnomalies(detectedAnomalies);
    } finally {
      setLoading(false);
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-slate-900 mb-2">Anomaly Detection System</h2>
        <p className="text-slate-600">Monitor city infrastructure and detect unusual patterns in real-time</p>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-600 text-sm font-medium">Active Monitors</p>
              <p className="text-2xl font-bold text-slate-900">24</p>
            </div>
            <div className="p-3 bg-blue-100 rounded-xl">
              <Eye className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-600 text-sm font-medium">Anomalies Detected</p>
              <p className="text-2xl font-bold text-red-600">{detectedAnomalies.length}</p>
            </div>
            <div className="p-3 bg-red-100 rounded-xl">
              <AlertTriangle className="h-6 w-6 text-red-600" />
            </div>
          </div>
        </div>
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-600 text-sm font-medium">System Health</p>
              <p className="text-2xl font-bold text-green-600">98.5%</p>
            </div>
            <div className="p-3 bg-green-100 rounded-xl">
              <Shield className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-600 text-sm font-medium">False Positives</p>
              <p className="text-2xl font-bold text-slate-900">2.1%</p>
            </div>
            <div className="p-3 bg-purple-100 rounded-xl">
              <TrendingDown className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Upload and Detection */}
        <div className="space-y-6">
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
            <h3 className="text-xl font-semibold text-slate-900 mb-4 flex items-center">
              <Upload className="h-5 w-5 mr-2 text-blue-500" />
              Upload Data for Analysis
            </h3>
            
            <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
              <AlertTriangle className="h-10 w-10 text-slate-400 mx-auto mb-3" />
              <p className="text-slate-600 mb-4">Upload CSV with KPI data for anomaly detection</p>
              <input
                type="file"
                accept=".csv"
                onChange={handleFileUpload}
                className="hidden"
                id="anomaly-upload"
              />
              <label
                htmlFor="anomaly-upload"
                className="inline-flex items-center px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 cursor-pointer transition-colors"
              >
                <Upload className="h-4 w-4 mr-2" />
                Choose CSV File
              </label>
            </div>

            {file && (
              <div className="mt-4 p-3 bg-green-50 rounded-lg">
                <p className="font-medium text-green-800">{file.name}</p>
                <p className="text-sm text-green-600">{data.length} data points loaded</p>
              </div>
            )}

            {data.length > 0 && (
              <button
                onClick={handleDetectAnomalies}
                disabled={loading}
                className="w-full mt-4 flex items-center justify-center px-6 py-3 bg-gradient-to-r from-red-500 to-orange-500 text-white rounded-lg hover:from-red-600 hover:to-orange-600 disabled:opacity-50 transition-all"
              >
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Analyzing Data...
                  </>
                ) : (
                  <>
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    Detect Anomalies
                  </>
                )}
              </button>
            )}
          </div>

          {/* Detected Anomalies */}
          {anomalies.length > 0 && (
            <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
              <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center">
                <AlertTriangle className="h-5 w-5 mr-2 text-red-500" />
                Detected Anomalies
              </h3>
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {anomalies.map((anomaly) => (
                  <div key={anomaly.id} className="p-4 border border-slate-200 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full border ${getSeverityColor(anomaly.severity)}`}>
                        {anomaly.severity.toUpperCase()}
                      </span>
                      <span className="text-xs text-slate-500">{anomaly.zone}</span>
                    </div>
                    <p className="font-medium text-slate-900">{anomaly.metric}</p>
                    <div className="text-sm text-slate-600 mt-1">
                      <span>Value: {anomaly.value}</span>
                      <span className="mx-2">|</span>
                      <span>Expected: {anomaly.expected}</span>
                      <span className="mx-2">|</span>
                      <span className={anomaly.deviation > 0 ? 'text-red-600' : 'text-blue-600'}>
                        {anomaly.deviation > 0 ? '+' : ''}{anomaly.deviation.toFixed(1)}%
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-1">{anomaly.timestamp}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Visualization */}
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
          <h3 className="text-xl font-semibold text-slate-900 mb-6">Real-time Monitoring</h3>
          
          {data.length > 0 ? (
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="time" stroke="#64748b" />
                  <YAxis stroke="#64748b" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px' 
                    }} 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="value" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    dot={(props) => {
                      const { cx, cy, payload } = props;
                      return payload.isAnomaly ? (
                        <circle cx={cx} cy={cy} r={6} fill="#ef4444" stroke="#fff" strokeWidth={2} />
                      ) : (
                        <circle cx={cx} cy={cy} r={3} fill="#3b82f6" />
                      );
                    }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-80 flex items-center justify-center text-slate-400">
              <div className="text-center">
                <AlertTriangle className="h-16 w-16 mx-auto mb-4" />
                <p>Upload data to view anomaly detection</p>
              </div>
            </div>
          )}

          <div className="mt-6 flex items-center space-x-4 text-sm">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
              <span>Normal Data</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
              <span>Anomalies</span>
            </div>
          </div>
        </div>
      </div>

      {/* Analysis Summary */}
      <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200">
        <h3 className="text-lg font-semibold text-slate-900 mb-4">Analysis Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-4 bg-red-50 rounded-lg">
            <h4 className="font-medium text-red-900 mb-2">Critical Issues</h4>
            <p className="text-sm text-red-700">Unusual energy spike in Sector 12 requires immediate investigation</p>
          </div>
          <div className="p-4 bg-yellow-50 rounded-lg">
            <h4 className="font-medium text-yellow-900 mb-2">Maintenance Alert</h4>
            <p className="text-sm text-yellow-700">Water pressure drop indicates potential pipe maintenance needed</p>
          </div>
          <div className="p-4 bg-blue-50 rounded-lg">
            <h4 className="font-medium text-blue-900 mb-2">System Status</h4>
            <p className="text-sm text-blue-700">Overall infrastructure performing within normal parameters</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnomalyDetection;